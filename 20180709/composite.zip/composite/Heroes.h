#ifndef HEROES_H_
#define HEROES_H_
#include <string>
#include <vector>


class Heroic {
    std::string name_;
  public:
    Heroic(std::string name);
    virtual ~Heroic();
    std::string name();
    virtual size_t salary() = 0;
};


class HeroTeam : public Heroic {
    std::vector<Heroic*> members;
  public:
    HeroTeam(std::string name);
    ~HeroTeam();
    void add(Heroic*);
    size_t salary() override;
};

class Hero : public Heroic {
    size_t salary_;
  public:
    Hero(std::string, size_t);
    size_t salary() override;
};


#endif
// HEROES_H_
