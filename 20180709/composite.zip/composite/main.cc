#include "Heroes.h"
#include <iostream>
#include <string>
using namespace std;

Heroic * avengers() {
    HeroTeam *avengers = new HeroTeam("Avengers");
    avengers->add(new Hero("Iron Man", 1000000000));
    avengers->add(new Hero("Black Widow", 100000));
    avengers->add(new Hero("Hulk", 100000));
    avengers->add(new Hero("Thor", 100000));
    return avengers;
}

Heroic * spidermen() {
    HeroTeam *spidermen = new HeroTeam("Spider-Men");
    spidermen->add(new Hero("Miles Morales", 0));
    spidermen->add(new Hero("Peter Parker", 0));
    spidermen->add(new Hero("Tobey Maguire", 4000000));
}

Heroic * MCU() {
    HeroTeam *mcu = new HeroTeam("MCU");
    mcu->add(avengers());
    mcu->add(new Hero("Captain America",100000));
    mcu->add(new Hero("Doctor Strange", 100000));
    mcu->add(new Hero ("Black Panther", 100000));
    return mcu;
}

int main() {
    HeroTeam myHeroes("Heroes");
    myHeroes.add(MCU());
    myHeroes.add(spidermen());
    myHeroes.add(new Hero("Squirrel Girl", 50));
    
    for (auto &it : myHeroes) {
        cout << it.name() << " : " << it.salary() << endl;
    }
    /* We want the Above to print:
     * Heroes : 1004600050
     * MCU : 1000600000
     * Avengers : 1000630000
     * Iron Man : 1000000000
     * Black Widow : 100000
     * Hulk : 100000
     * Thor : 100000
     * Captain America : 100000
     * Doctor Strange : 100000
     * Black Panther : 100000
     * Spider-Men : 4000000
     * Miles Morales : 0
     * Peter Parker : 0
     * Tobey Macguire : 4000000
     * Squirrel Girl : 50
     */
}
