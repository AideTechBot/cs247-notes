#include "Heroes.h"
#include <string>
using namespace std;


Heroic::Heroic(string name) : name_(name) {}
std::string Heroic::name() { return name_; }

HeroTeam::HeroTeam(std::string name) : Heroic(name) {}
HeroTeam::~HeroTeam() {
    for (auto &it : members) {
        delete it;
    }
}

size_t HeroTeam::salary() {
    size_t sal = 0;
    for (auto &it : members) {
        sal += it->salary();
    }
    return sal;
}
void HeroTeam::add(Heroic*hero) {
    members.emplace_back(hero);
}

Hero::Hero(std::string name, size_t sal) : Heroic(name), salary_(sal) {}

size_t Hero::salary() { return salary_; }
